import React, { useState } from 'react';
import { AgenticMount } from '@ae/host-sdk';
import '@ae/ui/styles.css';

// Synthetic fixture integration. Production hosts supply their own session boundary,
// navigation placement, reserved actions and modal suspension. This is not an admin grant.
export function HelpdeskAgenticMount({ onChanged }: { onChanged: () => void | Promise<void> }) {
  const [managementVisible, setManagementVisible] = useState(false);
  return <><nav aria-label="Helpdesk administration"><button type="button" aria-expanded={managementVisible} aria-controls="helpdesk-agentic-settings" onClick={() => setManagementVisible(value => !value)}>Agentic settings & activity</button></nav>
    <div id="helpdesk-agentic-settings"><AgenticMount apiBase="/api" ticketId="ticket-1" floating={{ applicationId: 'helpdesk-fixture', reservedAreas: [{ left: 0, top: 0, right: 360, bottom: 180 }] }} managementVisible={managementVisible} onRunChange={run => { if (run.status === 'succeeded') void onChanged(); }} /></div>
  </>;
}
